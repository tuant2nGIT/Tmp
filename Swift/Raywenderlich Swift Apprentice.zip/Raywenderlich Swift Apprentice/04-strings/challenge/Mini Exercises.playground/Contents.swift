import Foundation

let firstName = "Matt"
let lastName = "Galloway"

let fullName = firstName + " " + lastName

let myDetails = "Hello, my name is \(fullName)."
